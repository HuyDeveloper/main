#include <stdio.h>

int check_password(char *buf) {
    if (buf[0] == 'h' && buf[1] == 'e' &&
        buf[2] == 'l' && buf[3] == 'l' &&
        buf[4] == 'o')
        return 1;
    return 0;
}

int main() {
    char buf[6]; // Khai báo mảng char để lưu chuỗi nhập vào

    // Nhập chuỗi từ bàn phím
    printf("Nhập chuỗi: ");
    scanf("%5s", buf); // Sử dụng %5s để chỉ định số lượng kí tự tối đa là 5 để tránh tràn bộ nhớ

    // Kiểm tra mật khẩu và in ra kết quả
    if (check_password(buf)) {
        printf("Mật khẩu đúng!\n");
    } else {
        printf("Mật khẩu sai!\n");
    }

    return 0;
}

