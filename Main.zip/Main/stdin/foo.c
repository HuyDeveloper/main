#include <stdio.h>

int main() {
    char c;
    scanf("%c", &c);
    
    if (c >= 'a' && c <= 'z')
        printf("chữ thường\n");
    else if (c >= 'A' && c <= 'Z')
        printf("chữ hoa\n");
    else
        printf("Khác\n");
        
    return 0;
}

