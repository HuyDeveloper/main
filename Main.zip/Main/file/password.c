#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int check_password(int fd) {
  char buf[5];
    if (buf[0] == 'h' && buf[1] == 'e' &&
	buf[2] == 'l' && buf[3] == 'l' &&
	buf[4] == 'o')
      return 1; 
  return 0;
}

int main(int argc, char **argv) {


  if (check_password(0)) {
    printf("Password found in standard input\n");
    return 0;
  }

  return 1;
}
