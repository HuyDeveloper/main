#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
int main() {
    int num;
    
    // Đọc dữ liệu từ stdin sử dụng sym-stdin
    if (read(0, num, 2) != -1) {
        // Kiểm tra xem số đó là số chẵn hay số lẻ và in ra kết quả tương ứng
        if (num % 2 == 0)
            printf("Even number\n");
        else
            printf("Odd number\n");
    }
    return 0;
}
