import sys
import subprocess

# Kiểm tra xem có đủ đối số dòng lệnh không
if len(sys.argv) < 3:
    print("Usage: python script.py <filename>")
    sys.exit(1)

# Lấy tên tệp từ dòng lệnh
filename = sys.argv[1]
filename2 = sys.argv[2]
# Danh sách các lệnh cần thực thi
commands = [
    f"mkdir {filename}", #data input of filename
    f"mkdir {filename}_output",
    f"mkdir {filename}_clone_output",
    
    f"mkdir {filename2}",#data input of filename2
    f"mkdir {filename2}_output",
    f"mkdir {filename2}_clone_output",
    
    f"python3 script.py {filename} {option}",
    f"python3 script.py {filename2} {option}",
    
    "clang RunScriptV1.c -o run",
    
    f"python3 wrap.py {filename} argv {filename}_exe {filename}_output",
    f"python3 wrap.py {filename} argv {filename2}_exe {filename}_clone_output"
    
    f"python3 wrap.py {filename2} argv {filename}_exe {filename}_output",
    f"python3 wrap.py {filename2} argv {filename2}_exe {filename}_clone_output",
    
    f"python3 compare.py {filename}_output/ {filename}_clone_output 1",
    f"python3 compare.py {filename2}_output/ {filename2}_clone_output 2",
    
]

# Thực thi mỗi lệnh và in ra kết quả
for command in commands:
    print("Executing command:", command)
    subprocess.run(command, shell=True)
    print("Command executed successfully")

