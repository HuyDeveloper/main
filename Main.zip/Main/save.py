import subprocess
import re
import sys

def count_lines(filename):
    with open(filename, 'r') as file:
        line_count = sum(1 for line in file)
    return line_count

def read_lines(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()
    return lines

def run_ktest(N):
    input_string = "000000"

    command = "ktest-tool "

    for i in range(1, N+1):
        # Tạo số với độ dài 6 và thêm vào chuỗi "000000"
        new_number = str(i).zfill(6)
        # In kết quả
        file = "klee-last/test" + input_string[:-len(new_number)] + new_number + ".ktest > ktest/" +  str(i) + ".txt"
        subprocess.run(command + file, shell=True, capture_output=True, text=True)

def argument_extract(file_name):
    list_arg_name = []
    list_arg_type = []
    with open(file_name, 'r') as output_file:
        for line in output_file:
            if line.startswith("Function Name:"):
                function_name = line.split(" ")[-1].strip()
            elif line.startswith("Cursor Info:"):
                cursor_info = line.split(" ")[-1].strip()
            elif line.startswith("Return Type:"):
                return_type = line.split(": ")[-1].strip()
            elif line.startswith("Number of Arguments:"):
                num_arguments = int(line.split(" ")[-1].strip())
            elif line.startswith("Argument"):
                parts = line.split("=")
                a = parts[1].split("Type")
                arg_name = a[0].strip()
                arg_type = a[1].split(": ")[1].strip()
                list_arg_name.append(arg_name)
                list_arg_type.append(arg_type)

        return list_arg_name, list_arg_type


def save_input(N, filePath):
    j = 1
    for i in range(1, N + 1):
        with open("ktest/" + str(i) + ".txt") as file:
            lines = file.readlines()

        for line in lines:
            name = ""
            data = ""
            flag = 0
            if 'name' in line:
                name = line.split("'")[1]

            elif 'hex' in line:
                data = line.split("0x")[-1].strip()
                flag = 1;

            if flag:
                j = j + 1
                object_number = line.split(" ")[1][:-1]
                with open(f"{filePath}/{object_number}.txt", "a") as input_file:
                    input_file.write(data)
                    input_file.write("\n")





if __name__ == "__main__":
    # Thêm xử lý tham số dòng lệnh để lấy đường dẫn tệp
    if len(sys.argv) < 2:
        print("Usage: python3 script.py filePath")
        sys.exit(1)

    file_path = "klee-last/info"
    line = read_lines(file_path)

    N = line[count_lines(file_path) - 1].split("= ")[1].strip()

    run_ktest(int(N))

    # Chạy hàm `save_input` với đường dẫn tệp
    save_input(int(N), sys.argv[1])


