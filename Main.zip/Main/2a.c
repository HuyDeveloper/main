#include <stdio.h>

int main(int argc, char **argv) {
    int x, y;
    if (argc != 3) {
        printf("Usage: %s <x> <y>\n", argv[0]);
        return -1;
    }
    argv[1][1] = '\0';
    argv[2][1] = '\0';
    x = atoi(argv[1]);
    y = atoi(argv[2]);
    if (x == y) {
        printf("x is equal to y\n");
    } else if (x < y) {
        printf("x is less than y\n");
    } else {
        printf("x is greater than y\n");
    }
    return 0;
}

