#include <stdio.h>
#include <stdlib.h>
#include <string.h> // Thêm thư viện này để sử dụng hàm strcmp

#include "./SaveInput.c"

int readNumArgsFromFile() {
    FILE *fp = fopen("num_argvs.txt", "r");
    if (fp == NULL) {
        printf("Error opening file num_argvs.txt\n");
        exit(1);
    }
    int num_args;
    fscanf(fp, "%d", &num_args);
    fclose(fp);
    return num_args;
}


int main (int argc, char *argv[]){
    if(argc < 4) {
        printf("Usage: %s <File_name_string> <mode> <data>\n", argv[0]);
        return 1;
    }
    // Tạo một chuỗi để chứa lệnh được tạo ra
    int num_args = readNumArgsFromFile();

    // Lưu command từ argv[3]
    char command[100];
    strcpy(command, "./");
    strcat(command, argv[1]);

    if(strcmp(argv[2], "argv") == 0) { // So sánh chuỗi sử dụng hàm strcmp
        // Sử dụng hàm snprintf để tạo lệnh
	for (int i = 0; i < num_args; i++) {
        	char original_string[100];
		int temp = i + 3;
        	hexToString(argv[temp], original_string);
        	strcat(command, " ");
        	strcat(command, original_string);
	}
    }
    else if(strcmp(argv[2], "stdin") == 0) { // So sánh chuỗi sử dụng hàm strcmp
        snprintf(command, sizeof(command), "./%s", argv[2]);
        // Không cần sử dụng "echo" ở đây
    }
    else {
        printf("Invalid mode\n");
        return 1;
    }
    system(command);

    return 0;
}

