#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  // Kiểm tra số lượng đối số truyền vào
  if (argc != 3) {
    fprintf(stderr, "Cách sử dụng: %s <số thứ nhất> <số thứ hai>\n", argv[0]);
    return 1;
  }

  // Chuyển đổi chuỗi sang số
  int num1 = atoi(argv[1]);
  int num2 = atoi(argv[2]);

  // Tính tổng
  int sum = num1 + num2;

  // In kết quả
  printf("Tổng hai số %d và %d là: %d\n", num1, num2, sum);

  return 0;
}



