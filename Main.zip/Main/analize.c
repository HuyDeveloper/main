#include <stdio.h>
#include <clang-c/Index.h>

void analyze_source(const char *filename) {
    // Tạo một Index
    CXIndex index = clang_createIndex(0, 0);

    // Phân tích tệp nguồn
    CXTranslationUnit tu = clang_parseTranslationUnit(index, filename,
                                                       NULL, 0,
                                                       NULL, 0,
                                                       CXTranslationUnit_None);

    // Lấy AST (Abstract Syntax Tree)
    CXCursor cursor = clang_getTranslationUnitCursor(tu);

    // Lặp qua tất cả các nút trong AST
    clang_visitChildren(cursor, [](CXCursor c, CXCursor parent, CXClientData client_data) -> CXChildVisitResult {
        CXString name = clang_getCursorSpelling(c);
        CXSourceLocation location = clang_getCursorLocation(c);
        CXFile file;
        unsigned int line, column, offset;

        clang_getExpansionLocation(location, &file, &line, &column, &offset);
        const char *filename = clang_getCString(clang_getFileName(file));
        printf("Node: %s, File: %s, Line: %u, Column: %u\n", clang_getCString(name), filename, line, column);

        clang_disposeString(name);

        return CXChildVisit_Recurse;
    }, NULL);

    // Giải phóng bộ nhớ
    clang_disposeTranslationUnit(tu);
    clang_disposeIndex(index);
}

int main() {
    const char *filename = "main.c";
    analyze_source(filename);
    return 0;
}

