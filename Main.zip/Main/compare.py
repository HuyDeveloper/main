import os
import sys
def read_file(file_path):
    with open(file_path, 'r') as file:
        return file.read()

def compare_folders(folder1, folder2, num):
    files1 = os.listdir(folder1)
    files2 = os.listdir(folder2)
    common_files = set(files1) & set(files2)
    total_files = len(common_files)
    if total_files == 0:
        print("No common files found.")
        return

    total_similarity = 0
    for file_name in common_files:
        file_path1 = os.path.join(folder1, file_name)
        file_path2 = os.path.join(folder2, file_name)
        data1 = read_file(file_path1)
        data2 = read_file(file_path2)
        if data1 == data2:
            percent = 100
        else:
            common_chars = sum(1 for a, b in zip(data1, data2) if a == b)
            percent = common_chars / len(data1) * 100
        total_similarity += percent
        print(f"Input: {file_name}")
        print(f"Output: {data1}")
        print(f"Output: {data2}")
        print(f"Similarity: {percent}%")

    average_similarity = total_similarity / total_files
    print(f"Average similarity of folders: {average_similarity}%")
    with open(os.path.join(f"{num}agv.txt"), "w") as f:
        f.write(f"{average_similarity:.2f}")  # Format as percentage with 2 decimals

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python script.py folder1 folder2")
        sys.exit(1)

    folder1 = sys.argv[1]
    folder2 = sys.argv[2]
    num = sys.argv[3]
    compare_folders(folder1, folder2, num)

