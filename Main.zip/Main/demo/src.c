#include <stdio.h>

int main() {
	stdin = freopen("text.txt", "r", stdin);
	int x = 10;
	int y;
	scanf("%d", &x);
	scanf("%d", &y);
	printf("%d\n", x * y );
	return 0;
}
