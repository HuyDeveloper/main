import sys
import os

def compile_and_run(filename):
    # Biên dịch file C thành file LLVM IR
    compile_command = f"clang -emit-llvm -c {filename}.c"
    os.system(compile_command)
    compile_command1 = f"clang {filename}.c -o {filename}"
    os.system(compile_command1)
    # Kiểm tra giá trị của argv[2]
    if len(sys.argv) >= 3:
        if sys.argv[2] == "argv":
            # Yêu cầu người dùng nhập số lượng và độ dài của argv
            num_args = input("Nhập số lượng đối số argv: ")
            arg_length = input("Nhập độ dài của mỗi đối số argv: ")
            # Lưu số lượng đối số argv vào tệp num_argvs.txt
            with open("num_argvs.txt", "w") as f:
                f.write(num_args)
            # Chạy KLEE với đối số ký hiệu hóa
            klee_command = f"klee -posix-runtime --libc=uclibc {filename}.bc -sym-args {num_args} {num_args} {arg_length}"
            create_execute_command = f"clang {filename}.c -o {filename}_exe"
            os.system(klee_command)
        elif sys.argv[2] == "stdin":
            # Chạy KLEE với stdin ký hiệu hóa và stdout
            klee_command = f"klee -posix-runtime --libc=uclibc {filename}.bc -sym-stdin 1 -sym-stdout"
            os.system(klee_command)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 script.py filename [argv | stdin]")
        sys.exit(1)

    filename = sys.argv[1]
    compile_and_run(filename)

