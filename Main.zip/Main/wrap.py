import sys
import os
import subprocess

def execute_command(data,file, additional_argument, i, filename):
    command = "./run"
    # Tạo list chứa các thành phần của command
    command_parts = [command, file,additional_argument, data, ">",f"{filename}_output/{i}.txt"]
    # Chuyển list thành một command line string
    command_line = ' '.join(command_parts)
    # Thực thi command line
    print(command_line)
    subprocess.run(command_line, shell=True)


def count_lines(file_path):
    with open(file_path, 'r') as file:
        return len(file.readlines())

def read_line_n(file_path, n):
    with open(file_path, 'r') as file:
        for i, line in enumerate(file):
            if i == n - 1:  # Dòng đếm từ 0, nên cần trừ đi 1 để lấy dòng thứ n
                return line.strip()  # Trả về dòng thứ n đã được loại bỏ khoảng trắng

    # Trả về None nếu không tìm thấy dòng thứ n trong tệp
    return None

def main():
    if len(sys.argv) < 4:
        print("Usage: python script.py folder [argv|stdin] filename num")
        return

    folder = sys.argv[1]
    additional_argument = sys.argv[2]
    file_name = sys.argv[3]
    num = sys.argv[4]
    data_path = f"{folder}/0.txt"
    lines = count_lines(data_path)
    # Lấy danh sách các file trong thư mục
    files = os.listdir(folder)
    # Sắp xếp theo thứ tự tăng dần
    files.sort(key=lambda x: int(x.split('.')[0]))

    for i in range(1,lines+1):
        datas = ""
        for file_name in files:
            file_input = os.path.join(folder, file_name)
            line_n = read_line_n(file_input, i)
            datas += line_n + " "
        datas = datas.rstrip()
        execute_command(datas, sys.argv[3], additional_argument, i, num)

if __name__ == "__main__":
    main()
