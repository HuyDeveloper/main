#include<stdio.h>

int main() {
    char input[100];
    fgets(input, sizeof(input), stdin);
    printf("Chuỗi đã nhập: %s", input);
    return 0;
}

