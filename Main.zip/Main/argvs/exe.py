import sys
import os
import subprocess

def execute_command(data, additional_argument):
    command = "./run"
    full_command = [command, additional_argument, data]
    print("Executing command:", ' '.join(full_command))
    subprocess.run(full_command)
def count_lines(file_path):
    with open(file_path, 'r') as file:
        return len(file.readlines())
        
def read_line_n(file_path, n):
    with open(file_path, 'r') as file:
        for i, line in enumerate(file):
            if i == n - 1:  # Dòng đếm từ 0, nên cần trừ đi 1 để lấy dòng thứ n
                return line.strip()  # Trả về dòng thứ n đã được loại bỏ khoảng trắng

    # Trả về None nếu không tìm thấy dòng thứ n trong tệp
    return None
        
def main():
    if len(sys.argv) < 3:
        print("Usage: python script.py folder [argv|stdin]")
        return

    folder = sys.argv[1]
    additional_argument = sys.argv[2]
    data_path = f"{folder}/0.txt"
    lines = count_lines(data_path)
    # Lấy danh sách các file trong thư mục
    files = os.listdir(folder)
    # Sắp xếp theo thứ tự tăng dần
    files.sort(key=lambda x: int(x.split('.')[0]))
    
    for i in range(1,lines+1):
        datas = ""
        for file_name in files:
            file_input = os.path.join(folder, file_name)
            line_n = read_line_n(file_input, i)
            datas += line_n + " "
 
        execute_command(datas, additional_argument)

if __name__ == "__main__":
    main()

