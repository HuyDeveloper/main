import sys
import os
import subprocess

# Check for sufficient command-line arguments
if len(sys.argv) < 3:
    print("Usage: python script.py <filename1> <filename2> <option>")
    sys.exit(1)

# Extract filenames and option from command line
filename1 = sys.argv[1]
filename2 = sys.argv[2]
option = sys.argv[3] if len(sys.argv) > 3 else None  # Handle optional option

# Define folder creation commands
folder_creation_commands = [
    f"mkdir -p {filename1}",  # Create folders with -p flag to avoid errors if already exist
    f"mkdir -p {filename1}_output",
    f"mkdir -p {filename1}_clone_output",

    f"mkdir -p {filename2}",
    f"mkdir -p {filename2}_output",
    f"mkdir -p {filename2}_clone_output",
]

# Create necessary folders
for command in folder_creation_commands:
    print("Executing command:", command)
    subprocess.run(command, shell=True)

# Define remaining commands (assuming script.py, wrap.py, compare.py exist)
remaining_commands = [
    f"python3 script.py {filename1} {option}",
    f"python3 script.py {filename2} {option}",

    "clang RunScriptV1.c -o run",

    f"python3 wrap.py {filename1} argv {filename1}_exe {filename1}_output",
    f"python3 wrap.py {filename1} argv {filename2}_exe {filename1}_clone_output",

    f"python3 wrap.py {filename2} argv {filename2}_exe {filename2}_output",
    f"python3 wrap.py {filename2} argv {filename2}_exe {filename2}_clone_output",

    f"python3 compare.py {filename1}_output/ {filename1}_clone_output 1",
    f"python3 compare.py {filename2}_output/ {filename2}_clone_output 2",
]

# Execute remaining commands after folder creation
for command in remaining_commands:
    print("Executing command:", command)
    subprocess.run(command, shell=True)

# Function to read and average values from files (assuming valid format)
def read_and_average_values(file1_path, file2_path):
    try:
        with open(file1_path, 'r') as f1, open(file2_path, 'r') as f2:
            value1 = float(f1.read())
            value2 = float(f2.read())
            average = (value1 + value2) / 2
            return average
    except (FileNotFoundError, ValueError):
        print(f"Error reading values from {file1_path} or {file2_path}")
        return None

# Read and average values from 1agv.txt and 2agv.txt
average_similarity = read_and_average_values(f"{filename1}_output/1agv.txt", f"{filename2}_output/2agv.txt")

# Handle successful or unsuccessful average calculation
if average_similarity is not None:
    print(f"Average similarity: {average_similarity:.2f}%")  # Format as percentage with 2 decimals
else:
    print("Failed to calculate average similarity due to errors.")
