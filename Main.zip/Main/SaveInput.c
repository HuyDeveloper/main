#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int hexCharToInt(char c) {
    if (c >= '0' && c <= '9')
        return c - '0';
    else if (c >= 'a' && c <= 'f')
        return c - 'a' + 10;
    else if (c >= 'A' && c <= 'F')
        return c - 'A' + 10;
    else
        return -1; // Trả về -1 nếu ký tự không hợp lệ
}

// Hàm chuyển đổi chuỗi hexa thành chuỗi char[]
void hexToString(const char* hex, char* result) {
    size_t len = strlen(hex);
    size_t i;
    for (i = 0; i < len; i += 2) {
        int hi = hexCharToInt(hex[i]);
        int lo = hexCharToInt(hex[i + 1]);
        if (hi == -1 || lo == -1) {
            fprintf(stderr, "Ký tự hexa không hợp lệ!\n");
            result[0] = '\0'; // Trả về chuỗi rỗng nếu có lỗi
            return;
        }
        result[i / 2] = (char)((hi << 4) | lo);
    }
    result[i / 2] = '\0'; // Kết thúc chuỗi ký tự
}

char intToHexChar(int x) {
    if (x >= 0 && x <= 9)
        return '0' + x;
    else if (x >= 10 && x <= 15)
        return 'A' + (x - 10);
    else {
        fprintf(stderr, "Giá trị không hợp lệ: %d\n", x);
        return '\0';
    }
}

// Hàm chuyển đổi mảng char thành chuỗi hexa
void stringToHex(const char* str, char* result) {
    size_t len = strlen(str);
    size_t i;
    for (i = 0; i < len; ++i) {
        unsigned char c = str[i];
        result[i * 2] = intToHexChar((c >> 4) & 0xF);
        result[i * 2 + 1] = intToHexChar(c & 0xF);
    }
    result[i * 2] = '0';
    result[i * 2 + 1] = '0';
}

void string_to_hex(const char *input_string, char *hex_string) {
    int i, len = strlen(input_string);
    for (i = 0; i < len; ++i) {
        sprintf(hex_string + i * 2, "%02x", input_string[i]);
    }
}

void saveInt(int data, const char* filename) {
    FILE *file;
    file = fopen(filename, "a");
    //printf("%d\n", data);
    fprintf(file, "%d\n", data);
    
    fclose(file);
}

void saveLong(long data, const char* filename) {
    FILE *file;
    file = fopen(filename, "a");
    
    fprintf(file, "%ld\n", data);
    
    fclose(file);
}

void saveUnsigned(unsigned int data, const char* filename) {
    FILE *file;
    file = fopen(filename, "a");
    
    fprintf(file, "%u\n", data);
    
    fclose(file);
}

char halfbyte_to_hexchar(unsigned char halfbyte) {
    return halfbyte < 10 ? (halfbyte + '0') : (halfbyte - 10 + 'A');
}

// Hàm chuyển đổi byte thành hai ký tự hexa
void byte_to_hexchars(unsigned char byte, char *hexchars) {
    hexchars[0] = halfbyte_to_hexchar((byte >> 4) & 0x0F);
    hexchars[1] = halfbyte_to_hexchar(byte & 0x0F);
}

// Hàm chuyển đổi chuỗi ký tự thành chuỗi hexa và lưu vào tệp
void string_to_hex_and_save(const char *input_string, FILE *file) {
    // Lặp qua từng ký tự trong chuỗi đầu vào
    for (int i = 0; i < strlen(input_string); i++) {
        // Chuyển đổi ký tự hiện tại thành hai ký tự hexa và ghi vào tệp
        char hexchars[3];
        byte_to_hexchars(input_string[i], hexchars);
        fprintf(file, "%c%c", hexchars[0], hexchars[1]);
    }

    fprintf(file, "\n");
}

void saveChar(char data[], const char* filename) {
    FILE *file;
    file = fopen(filename, "a");

    string_to_hex_and_save(data, file);
    
    fclose(file);
}

void saveArrayInt(int data[] , const char* filename) {
    FILE *file;
    file = fopen(filename, "a");
    for (int i = 0; i < 100;i++)
        fprintf(file, "%d ", data[i]);
    fprintf(file, "\n");
    fclose(file);
}

void saveArrayLong(long data[], const char* filename) {
    FILE *file;
    file = fopen(filename, "a");
    
    for (int i = 0; i < 100;i++)
        fprintf(file, "%ld ", data[i]);
    fprintf(file, "\n");
    
    fclose(file);
}

void saveArrayUnsigned(unsigned int data[], const char* filename) {
    FILE *file;
    file = fopen(filename, "a");
    
    for (int i = 0; i < 100;i++)
        fprintf(file, "%u ", data[i]);
    fprintf(file, "\n");
    
    fclose(file);
}
